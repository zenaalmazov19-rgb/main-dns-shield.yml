package com.example.adblock

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class DnsProvider(val name: String, val hostname: String, val description: String)

class MainActivity : ComponentActivity() {
    private val providers = listOf(
        DnsProvider("AdGuard DNS", "dns.adguard-dns.com", "Блокирует рекламу и многие трекеры."),
        DnsProvider("AdGuard Family", "family.adguard-dns.com", "Блокировка рекламы + контента для взрослых."),
        DnsProvider("Cloudflare Malware", "security.cloudflare-dns.com", "Фильтрация вредоносных доменов, без обычной блокировки рекламы.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                DnsBlocklistScreen(
                    providers = providers,
                    onOpenPrivateDns = {
                        runCatching {
                            startActivity(Intent("android.settings.PRIVATE_DNS_SETTINGS"))
                        }.getOrElse {
                            startActivity(Intent(Settings.ACTION_SETTINGS))
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun DnsBlocklistScreen(
    providers: List<DnsProvider>,
    onOpenPrivateDns: () -> Unit
) {
    var selected by remember { mutableStateOf(0) }
    var copied by remember { mutableStateOf(false) }
    val provider = providers[selected]
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("AdBlock DNS", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Без VPN • DNS-блоклист", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Важно", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Приложение не запускает VpnService и не отключает ваш VPN. " +
                        "Для системной DNS-блокировки нужно выбрать DNS-провайдера в настройках Android."
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("DNS-блоклист", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))

        providers.forEachIndexed { index, item ->
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                onClick = { selected = index; copied = false }
            ) {
                Row(Modifier.padding(16.dp)) {
                    RadioButton(selected = selected == index, onClick = { selected = index; copied = false })
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(item.name, style = MaterialTheme.typography.titleMedium)
                        Text(item.hostname, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(item.description, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(onClick = onOpenPrivateDns, modifier = Modifier.fillMaxWidth()) {
            Text("Открыть настройки Private DNS")
        }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Private DNS", provider.hostname))
                copied = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (copied) "Хостнейм выбран: ${provider.hostname}" else "Показать DNS-хостнейм")
        }

        Spacer(Modifier.height(16.dp))
        Text("Как включить", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "1. Нажмите «Открыть настройки Private DNS».\n" +
                "2. Выберите «Имя хоста провайдера Private DNS».\n" +
                "3. Введите: ${provider.hostname}\n" +
                "4. Сохраните настройку.\n\n" +
                "Если ваш основной VPN использует собственный DNS или полностью перехватывает DNS-запросы, " +
                "Private DNS может не применяться. В таком случае DNS-блокировку нужно включить непосредственно в настройках вашего VPN."
        )
    }
}
